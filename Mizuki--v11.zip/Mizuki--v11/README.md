[![Open Source Love svg3](https://badges.frapsoft.com/os/v3/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)<img align="centre" src="https://img.shields.io/badge/Made%20for-VSCode-1f425f.svg" alt="Red-Alison"/><img align="centre" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"/>

# ⬡ 👓Qtell™ △▽ 𝖂𝖍𝖆𝖙𝖘𝖆𝖕𝖕-𝖀𝖘𝖊𝖗𝖇𝖔𝖙 ⬡
𝘽𝙊𝙏 𝙄𝙉 𝘽𝙀𝙏𝘼
ʏᴏᴜʀ ᴀꜱꜱɪꜱꜱᴛᴀɴᴛ ꜰᴏʀ ᴍᴀᴋɪɴɢ ʙᴏʀɪɴɢ ᴡʜᴀᴛꜱᴀᴘᴘ ᴀ ʙᴇᴛᴛᴇʀ ᴀᴅᴠᴀɴᴄᴇ ᴀᴘᴘ!

<p align="center">
  <img src="https://i.postimg.cc/GtQgX45F/photo.jpg"/>
</p>

# ❓ 𝖂𝖍𝖞 𝕸𝖆𝖉𝖊 𝕿𝖍𝖎𝖘 𝕭𝖔𝖙?

```sh
💻 𝗪𝗵𝗮𝘁 𝗖𝗮𝗻 𝗕𝗼𝘁 𝗗𝗼???

🎮Qtell
🔸 ᴀᴅᴠᴀɴᴄᴇᴅ ᴡʜᴀᴛꜱᴀᴘᴘ ᴜꜱᴇʀʙᴏᴛ ᴡɪᴛʜ 80+ ᴄᴏᴍᴍᴀɴᴅꜱ ꜰᴏʀ ʙᴏᴛʜ ᴘʀɪᴠᴀᴛᴇ ᴀɴᴅ ɢʀᴏᴜᴘ-ᴜꜱᴀɢᴇ
🔸 Qtell is written in JavaScript and is by far the most advance Whatsapp Userbot.
🔸 Use Qtell in both public-groups and private
🔸 So many commands that will blow up the every-day use of boring whatsapp.
```

# ⚡ 𝕯𝖊𝖕𝖑𝖔𝖞𝖒𝖊𝖓𝖙
 *video download and watch*
- ꜰɪʀꜱᴛ ꜰᴏʀᴋ ᴀɴᴅ ꜱᴛᴀʀ ᴛʜᴇ ʀᴇᴘᴏ (or else auto upgrading won't work)

*text and link*
- ꜰɪʀꜱᴛ ꜰᴏʀᴋ ᴀɴᴅ ꜱᴛᴀʀ ᴛʜᴇ ʀᴇᴘᴏ (or else auto upgrading won't work)
- Make Heroku Account If You Don't Have already.
- Link to [Heroku](https://dashboard.heroku.com/apps)
- Get Your Heroku-Api Key From [Heroku API Key](https://dashboard.heroku.com/account)
- Get Your Mee6 SessionCode from [![Generic badge](https://img.shields.io/badge/Mee6_Session-blue.svg)](https://replit.com/@red-alison/Qtell)
- Head Over To [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/red-alison/Qtell.git) 
- Put All The Informations In the Box given in heroku (env vars)
- Click deploy and wait for deployment to get done (takes 10-15mins)
- After Deployment is done a new button appears "Manage Apps"
- Click on it and 𝘌𝘯𝘢𝘣𝘭𝘦 𝘵𝘩𝘦 𝘥𝘺𝘯𝘰 𝘪𝘯 𝘩𝘦𝘳𝘰𝘬𝘶
- Click on logs in the top right corner of the page
- If all went right then check your whatsapp for confirmation
- If anything went wrong Please 🐞RΣPӨЯƬ
🔸[ᴡʜᴀᴛꜱᴀᴘᴘ](https://chat.whatsapp.com/Ltg5YukK5Ug2a1mBsFhtFi)
🔸[ᴅɪꜱᴄᴏʀᴅ](https://discord.gg/RH3pFHsH)


# 💡 𝕴𝖓𝖘𝖕𝖎𝖗𝖆𝖙𝖎𝖔𝖓
```
)¤•• ʙᴀɪʟᴇʏꜱ ᴡʜᴀᴛꜱᴀᴘᴘ ʟɪʙʀᴀʀʏ [https://github.com/adiwajshing/Baileys]
)¤•• ᴡʜᴀᴛꜱᴀᴘᴘ ᴡᴇʙ ᴀᴘɪ [https://github.com/pedroslopez/whatsapp-web.js/]
)¤•• ᴘʀɪɴᴄᴇ-ᴍᴇɴᴅɪʀᴀᴛᴛᴀ ꜱᴄ [https://github.com/BotsAppOfficial/BotsApp]
)¤•• ᴛᴇʟᴇɢʀᴀᴍ,ᴅɪꜱᴄᴏʀᴅ ʙᴏᴛꜱ ᴏꜰ ᴍʏ ᴏᴡɴ ʟᴍᴀᴏ
```


# ☣️ [𝕷𝖎𝖈𝖊𝖓𝖘𝖊](LICENSE)

```sh
Apache License
Version 2.0, January 2004
http://www.apache.org/licenses
—••÷[🎮 Qtell]÷••—
𝘈𝘥𝘷𝘢𝘯𝘤𝘦 𝘞𝘩𝘢𝘵𝘴𝘢𝘱𝘱 𝘜𝘴𝘦𝘳𝘣𝘰𝘵
has been licensed under Apache License
𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐂) 𝟐𝟎𝟐𝟏 Red-Alison | Red-Me | Alison
```
