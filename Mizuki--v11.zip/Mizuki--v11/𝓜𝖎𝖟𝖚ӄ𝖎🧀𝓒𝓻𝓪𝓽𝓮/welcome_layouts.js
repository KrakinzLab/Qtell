` 
••» 𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐓𝐨 ⚡𝐌𝐞𝐞𝟔™ 𝐓𝐞𝐚𝐦 «••
ʟᴇᴀʀɴ 𝓜𝖎𝖟𝖚ӄ𝖎: xhelp

📍𝗥𝘂𝗹𝗲𝘀
_ᴊᴜꜱᴛ ʙᴇ ᴘᴏʟɪᴛᴇ & ʙᴇ ᴘᴀᴛɪᴇɴᴛ_

🖥️𝗩𝗲𝗿𝘀𝗶𝗼𝗻
_𝓜𝓮𝓮6-𝓜𝖎𝖟𝖚ӄ𝖎-8.09nightly+livedaily_

❣️𝗜𝗺𝗽-𝗟𝗶𝗻𝗸𝘀
𝘎𝘪𝘵𝘩𝘶𝘣 = https://github.com/Krakinz
𝘋𝘪𝘴𝘤𝘰𝘳𝘥 = https://discord.gg/xcFN6NDHEV

🐙𝗟𝗶𝗰𝗲𝗻𝘀𝗲
ʜᴀꜱ ʙᴇᴇɴ ʟɪᴄᴇɴꜱᴇᴅ ᴜɴᴅᴇʀ ᴀᴘᴀᴄʜᴇ ʟɪᴄᴇɴꜱᴇ
ᴄᴏᴘʏʀɪɢʜᴛ(ᴄ)2021 ᴋʀᴀᴋɪɴᴢʟᴀʙ
`;

("https://chat.whatsapp.com/GDNPVuH3eMq72UOUHavZxH");
